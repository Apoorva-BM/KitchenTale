// login.component.ts
import { Component,OnInit, ViewChild , ElementRef } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
  username: string = '';
  password: string = '';

  @ViewChild('name') nameKey!: ElementRef;
  constructor(){

  }
  ngOnInit(): void {

  }


  onSubmit(){
    localStorage.setItem("name",this.nameKey.nativeElement.value);
  }


}
