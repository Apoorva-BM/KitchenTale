
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ItemService {
  private items: string[] = ['Item 1', 'Item 2', 'Item 3', 'Item 4'];
  private selectedItems: string[] = [];

  getItems() {
    return this.items;
  }

  getSelectedItems() {
    return this.selectedItems;
  }

  addItem(item: string) {
    this.items.push(item);
  }

  toggleItemSelection(item: string) {
    const index = this.selectedItems.indexOf(item);
    if (index === -1) {
      this.selectedItems.push(item);
    } else {
      this.selectedItems.splice(index, 1);
    }
  }
}
